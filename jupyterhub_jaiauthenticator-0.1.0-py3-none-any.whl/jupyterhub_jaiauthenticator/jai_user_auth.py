
import os
from jupyterhub.handlers import BaseHandler
from jupyterhub.auth import Authenticator
from jupyterhub.auth import LocalAuthenticator
from jupyterhub.utils import url_path_join
from tornado import gen, web
from traitlets import Unicode


class JaiUserLoginHandler(BaseHandler):

    @gen.coroutine
    def get(self):
        self.log.info("self " + self)


class JaiUserAuthenticator(Authenticator):
    """
    Accept the authenticated user name from the API request.
    """
    def login_url(self, base_url):
        """Override this when registering a custom login handler

        Generally used by authenticators that do not use simple form-based authentication.

        The subclass overriding this is responsible for making sure there is a handler
        available to handle the URL returned from this method, using the `get_handlers`
        method.

        Args:
            base_url (str): the base URL of the Hub (e.g. /hub/)

        Returns:
            str: The login URL, e.g. '/hub/login'
        """
        return url_path_join(base_url, '/login')

    def get_handlers(self, app):
        self.log.info("app info " + app)
        return [
            (r'/login', JaiUserLoginHandler),
        ]

    @gen.coroutine
    def authenticate(self, handler, data):
        self.log.info("data " + data)
        return data['username']
